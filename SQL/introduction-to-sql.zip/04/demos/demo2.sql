-- SELECT 'Hello', 'World';
-- SELECT 'Hello' as FirstWord, 'World' as SecondWord;
USE contacts;

SELECT p.person_first_name as FirstName 
FROM person p;