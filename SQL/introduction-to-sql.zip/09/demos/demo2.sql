-- CREATE DATABASE contacts_V2;
USE contacts_V2;

		
CREATE TABLE person
(
	person_id INTEGER,
    person_first_name VARCHAR(256),
    person_last_name VARCHAR(256)
);
